package com.w;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class WrapperResponse extends HttpServletResponseWrapper {
	HttpServletResponse response;
	public WrapperResponse(HttpServletResponse response) {
		super(response);
		// TODO Auto-generated constructor stub
		this.response = response;
	}
	@Override
	public void addCookie(Cookie cookie) {
		// TODO Auto-generated method stub
		System.out.println("[���䷹��]��������:" + cookie.getValue());
		// �ҹ��ڷ� �����Ͽ� ����
		cookie.setValue(cookie.getValue().toLowerCase());
		//super.addCookie(cookie);
		response.addCookie(cookie);
	}
}
