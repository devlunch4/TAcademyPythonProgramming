package com.w;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class RequestWrapper extends HttpServletRequestWrapper {
	HttpServletRequest request;
	public RequestWrapper(HttpServletRequest request) {
		super(request);
		// TODO Auto-generated constructor stub
		this.request = request;
	}
	@Override
	public String getParameter(String name) {
		// TODO Auto-generated method stub
		//return super.getParameter(name);
		// ������ ����
		// �ҹ��� -> �빮��
		String value = request.getParameter(name);
		System.out.println("[����]��������:" + value);
		return value.toUpperCase();
	}
	
}
