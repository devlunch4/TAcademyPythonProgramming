package model1;

public class User {
	int idx;			//` INT(11) NOT NULL AUTO_INCREMENT,
	String uid;			//` VARCHAR(50) NOT NULL COMMENT '���̵�',
	String upw;			//` VARCHAR(50) NOT NULL COMMENT '��й�ȣ',
	String regdate;		//` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '������',
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
}
