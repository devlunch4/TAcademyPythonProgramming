package com.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "cs", description = "������ ��� ������", urlPatterns = { "/cs" })
public class ConnServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn = null;
	String url = "jdbc:mysql://localhost:3306/myDB";
	String id  = "root";
	String pw  = "1234";
	
    public ConnServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("��� �ʱ�ȭ");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("����Ϸ�");		
		} catch (Exception e) {
			System.out.println("�������");
		}
	}
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("��� ����");
		try{
			if( conn != null ){
				conn.close();
				System.out.println("���� ����");
			}
		}catch(Exception e){
			System.out.println("���� ���� ����");
		}
		System.out.println("�ɹ����� ���� : DB ��������");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("��� ���� ���� ����");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
