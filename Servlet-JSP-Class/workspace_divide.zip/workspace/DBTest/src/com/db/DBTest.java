package com.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "dbConnect", description = "�����ͺ��̽� ���� �׽�Ʈ", urlPatterns = { "/dbConnect" })
public class DBTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DBTest() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// DB ���� Ȯ��
		String url = "jdbc:mysql://localhost:3306/myDB";
		String id  = "root";
		String pw  = "1234";
		// 1.�ܰ� ����̹� �ε�
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// 2�ܰ� ����
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("����Ϸ�");
			// 3�ܰ� ���� 
			// 4�ܰ� ���� ����
			conn.close();
			System.out.println("��������");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("�������");
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
