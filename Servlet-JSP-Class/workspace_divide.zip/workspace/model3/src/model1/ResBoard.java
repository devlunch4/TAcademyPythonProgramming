package model1;

import java.util.ArrayList;

public class ResBoard {
	int code;
	ArrayList<Board> boards;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public ArrayList<Board> getBoards() {
		return boards;
	}
	public void setBoards(ArrayList<Board> boards) {
		this.boards = boards;
	}
	
}
