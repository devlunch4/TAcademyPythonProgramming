package com.s;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import model1.User;

@WebServlet(name = "joinProc", description = "ȸ������", urlPatterns = { "/joinProc" })
public class JoinProc extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn;
    public JoinProc() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		try {
			Context initCtx = new InitialContext();
			Context envCtx  = (Context)initCtx.lookup("java:comp/env");
			DataSource ds   = (DataSource)envCtx.lookup("jdbc/java");
			conn		    = ds.getConnection();
			System.out.println("Ŀ�ؼ� Ǯ�κ��� Ŀ�ؼ� ��ü ȹ��");			
			// ��������
			String uid 		= request.getParameter("uid");//"guest";
			String upw 		= request.getParameter("upw");//"1234";
			String sql 		= "insert into tbl_user (uid, upw) values (?,?)";
			PreparedStatement ps =  conn.prepareStatement(sql);
			ps.setString(1, uid);
			ps.setString(2, upw);
			
			int count = ps.executeUpdate();
			if( count > 0 ){
				request.setAttribute("code", "1");
			}else{
				request.setAttribute("code", "0");
			}			
			// �ݳ�
			conn.close();
			System.out.println("Ŀ�ؼ� Ǯ�κ��� Ŀ�ؼ� ��ü �ݳ� ");
			RequestDispatcher rd = request.getRequestDispatcher("joinOk.jsp");
			rd.forward(request, response);	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Ŀ�ؼ� ��ü ȹ�� ���� " + e.getMessage());
		}	
	}

}

